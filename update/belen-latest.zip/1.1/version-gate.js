(()=>{
  if(window.top!==window)return;
  const CURRENT_VERSION="1.1";
  const CHECK_INTERVAL_MS=60000;
  const DISCORD_URL="https://discord.com/channels/1552497584361447466/1553186610055487529";
  let host=null;
  const esc=v=>String(v).replace(/[<>&"']/g,c=>({"<":"&lt;",">":"&gt;","&":"&amp;",'"':"&quot;","'":"&#39;"}[c]));
  const getLatest=()=>new Promise(resolve=>{try{chrome.runtime.sendMessage({type:"BELEN_VERSION_CHECK"},r=>{if(chrome.runtime?.lastError){resolve(null);return}resolve(typeof r?.version==="string"?r:null)})}catch{resolve(null)}});
  const getState=()=>new Promise(resolve=>{try{chrome.storage.local.get("belenUpdateState",o=>resolve(o&&o.belenUpdateState||null))}catch{resolve(null)}});
  const triggerDownload=()=>{try{chrome.runtime.sendMessage({type:"BELEN_DOWNLOAD_UPDATE"},()=>{})}catch{}};
  const normalize=v=>String(v||"").trim().split(/\r?\n/)[0].trim();
  const lockPage=()=>{document.documentElement.style.overflow="hidden";document.body.style.overflow="hidden"};
  const unlockPage=()=>{if(host)return;document.documentElement.style.overflow="";document.body.style.overflow=""};
  const removeHost=()=>{host?.remove();host=null;unlockPage()};
  const overlayHTML=latest=>`
    <div class="bvg-backdrop"><div class="bvg-card"><div class="bvg-mark" style="background:#5865F2">B</div>
    <div><span class="bvg-badge" style="background:rgba(88,101,242,.16);border-color:rgba(88,101,242,.55);color:#b6beff">Update Available</span></div>
    <h1 class="bvg-title">A new version of Belen is ready</h1>
    <p class="bvg-sub">Your current version is out of date. Roblox will be locked until you update.</p>
    <div class="bvg-versions"><span class="bvg-pill">Latest <b>${esc(latest)}</b></span><span class="bvg-pill">Installed <b>${esc(CURRENT_VERSION)}</b></span></div>
    <p class="bvg-msg">Belen <b>${esc(latest)}</b> is downloading automatically. No files needed — once it finishes, open <b>chrome://extensions</b> and press <b>Reload</b> once to take effect.</p>
    <button type="button" class="bvg-btn" id="bvg-dl-btn" style="background:linear-gradient(135deg,#10b981,#0ea5e9);box-shadow:0 10px 30px rgba(16,185,129,.4)"><span id="bvg-dl-label">Download Update</span></button>
    <p class="bvg-dl-status" id="bvg-dl-status">Preparing update…</p>
    <a class="bvg-btn bvg-btn-link" style="background:linear-gradient(135deg,#5865F2,#7C5CFF);box-shadow:0 10px 30px rgba(88,101,242,.45)" href="${esc(DISCORD_URL)}" target="_blank" rel="noopener noreferrer">Get help on Discord<span class="bvg-arrow">&rarr;</span></a>
    <p class="bvg-foot"><span class="bvg-dot"></span>roblox.com stays locked until you update. Belen checks for updates automatically every minute.</p>
    </div></div>`;
  const setStatus=async root=>{
    const status=root.querySelector("#bvg-dl-status");
    const label=root.querySelector("#bvg-dl-label");
    if(!status||!label)return;
    const state=await getState();
    if(state&&state.downloadComplete){status.textContent="✓ Update downloaded to Downloads/Belen/belen-latest.zip — open chrome://extensions and press Reload once to finish.";status.className="bvg-dl-status ok";label.textContent="Download Update";}
    else if(state&&state.downloading){status.textContent="Downloading update automatically…";status.className="bvg-dl-status";label.textContent="Downloading…";}
    else if(state){status.textContent="Not downloaded yet — press Download Update.";status.className="bvg-dl-status";label.textContent="Download Update";}
    else{status.textContent="Preparing update…";status.className="bvg-dl-status";label.textContent="Download Update";}
  };
  const wireDownload=root=>{
    const btn=root.querySelector("#bvg-dl-btn");
    const label=()=>root.querySelector("#bvg-dl-label");
    if(btn)btn.addEventListener("click",async()=>{if(btn.disabled)return;btn.disabled=true;label().textContent="Starting…";triggerDownload();setTimeout(()=>{btn.disabled=false;setStatus(root)},1200)});
    try{chrome.storage.onChanged.addListener(changes=>{if(changes&&changes.belenUpdateState){setTimeout(()=>setStatus(root),100)}})}catch{}
    setInterval(()=>setStatus(root),2500);
    setStatus(root);
  };
  const buildOverlay=latest=>{
    if(host)return;
    const h=document.createElement("div");
    h.style.cssText="position:fixed;inset:0;z-index:2147483647;";
    const root=h.attachShadow({mode:"closed"});
    root.innerHTML=`<style>
      *{box-sizing:border-box;margin:0;padding:0}
      .bvg-backdrop{position:fixed;inset:0;z-index:1;display:flex;align-items:center;justify-content:center;padding:24px;background:radial-gradient(1200px 700px at 50% -10%,rgba(88,101,242,.2),transparent 60%),linear-gradient(180deg,rgba(8,12,28,.97),rgba(5,7,18,.99));font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;overflow:auto}
      .bvg-card{width:min(560px,100%);background:linear-gradient(180deg,#101827,#0b1120);border:1px solid rgba(139,154,255,.28);border-radius:22px;box-shadow:0 30px 90px rgba(0,0,0,.7),0 0 0 1px rgba(0,0,0,.35);padding:42px 36px 34px;text-align:center;color:#e8ebf5}
      .bvg-mark{display:inline-flex;align-items:center;justify-content:center;width:46px;height:46px;border-radius:14px;font:800 22px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#fff;margin-bottom:18px}
      .bvg-badge{display:inline-block;border:1px solid;font-size:11px;font-weight:800;letter-spacing:2.2px;text-transform:uppercase;padding:6px 14px;border-radius:999px;margin-bottom:16px}
      .bvg-title{font-size:24px;font-weight:800;line-height:1.25;margin-bottom:8px}
      .bvg-sub{color:#9aa3b8;font-size:14px;line-height:1.55;margin-bottom:22px}
      .bvg-versions{display:flex;justify-content:center;gap:10px;margin-bottom:22px;flex-wrap:wrap}
      .bvg-pill{font-size:13px;font-weight:700;padding:8px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:#dfe4f0}
      .bvg-pill b{font-weight:800}
      .bvg-versions .bvg-pill:first-child{border-color:rgba(52,211,153,.55);color:#6ee7b7;background:rgba(16,185,129,.12)}
      .bvg-versions .bvg-pill:first-child b{color:#34d399}
      .bvg-msg{font-size:15px;line-height:1.6;color:#c6cde0;margin-bottom:24px}
      .bvg-msg b{color:#fff}
      .bvg-btn{display:inline-flex;align-items:center;justify-content:center;gap:10px;width:100%;color:#fff;font-size:15px;font-weight:800;padding:15px 22px;border-radius:12px;border:none;cursor:pointer;font-family:inherit;transition:transform .12s ease,filter .12s ease;text-decoration:none}
      .bvg-btn:hover{filter:brightness(1.08)}
      .bvg-btn:active{transform:translateY(1px)}
      .bvg-btn:disabled{cursor:default;filter:grayscale(.3) brightness(.85)}
      .bvg-btn-link{margin-top:12px}
      .bvg-dl-status{margin:12px 0 0;font-size:13px;color:#7a8296;line-height:1.5;min-height:18px}
      .bvg-dl-status.ok{color:#34d399}
      .bvg-foot{margin-top:20px;font-size:12px;color:#7a8296;line-height:1.5}
      .bvg-dot{width:8px;height:8px;border-radius:50%;background:#34d399;display:inline-block;margin-right:6px;animation:bvg-blink 1.6s infinite}
      @keyframes bvg-blink{0%,100%{opacity:1}50%{opacity:.35}}
    </style>${overlayHTML(latest)}`;
    lockPage();
    document.documentElement.appendChild(h);
    host=h;
    wireDownload(root);
    triggerDownload();
  };
  const tick=async()=>{
    let p=null;
    try{p=await getLatest()}catch{p=null}
    const raw=p?normalize(p.version):"";
    if(raw){if(raw!==CURRENT_VERSION)buildOverlay(raw);else removeHost()}
  };
  tick();
  setInterval(tick,CHECK_INTERVAL_MS);
})();