export const BANNER_PAT = "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";
export const BANNER_OWNER = "belenclient";
export const BANNER_REPO = "belenclient.github.io";
export const BANNER_DIR = "banner_cache";